<?php 
$ret.= '<a href="'.$permalink.'">'.$image.'</a>';
$ret .='<div class="fs-itemdesc">';
    $ret.= '<h3><a href="'.$permalink.'">'.$title.'</a></h3>';
    if($result!="")
        $ret.= $result;
    else
        $ret.= woocommerce_price($base_price);
    //$ret.= $countdown;
$ret .='</div>';
?>