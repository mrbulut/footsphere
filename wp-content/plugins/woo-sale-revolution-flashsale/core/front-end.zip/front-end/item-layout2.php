<?php
$ret .='<div class="fl-post-cnt fl-boxed-cnt fl-boxed-layout1">';
	$ret.='<div class="fl-thumbnail">';
		if(trim($brands_attr['show_discount']) == "yes" ){
			$ret.='<div class="fl-banner fl-roundbanner">';
				$ret.='<span>' . $pw_discount_show.'</span>';
			$ret.='</div>';
		}
		$ret.='<a href="'.$permalink.'">'.'<div class="fl-thumbnail-overlay"></div>'.'</a>';
	$ret.='<div class="fl-boxed-detail-vis">';
		$ret.='<div class="fl-cat-meta">';
		$ret.='<span class="fl-meta-item">';
	$terms = get_the_terms( $a, 'product_cat' );
	if ( !is_wp_error( $terms ) ){
		if ( !empty( $terms ) ){
			foreach ( $terms as $term ) {	
				$link = get_term_link( $term, 'product_cat' );
				$ret .='<a href="'.$link.'">'. $term->name.'</a>';
			}	
		}
	}		
			$ret.='</span>';
		$ret.='</div>';
		$ret.='<div class="fl-title">';
			$ret.='<a href="'.$permalink.'">'.$title.'</a>';
		$ret.='</div>';
	$tax_display_mode = get_option( 'woocommerce_tax_display_shop' );				
	$base_price = $tax_display_mode == 'incl' ? $product->get_price_including_tax() : $product->get_price_excluding_tax();
	$type=array(
		'type'=>$pw_type_discount,
		'discount'=>$pw_discount,
	);
	
		$price=PW_Discount_Price::price_discunt($base_price,$type);
		$price=$base_price-$price;				
		$ret.='<div class="fl-price-cnt">';
			$ret.='<del> <span class="amount">'.woocommerce_price($base_price).'</span></del>';
			$ret.='<ins> <span class="amount">'.woocommerce_price($price).'</span></ins>';
		$ret.='</div>';
		
		if ($shortcode_name != 'flash_sale_product_rule'){
			if ( trim($brands_attr['show_countdown']) == "yes")
					$ret .= '<div class="fl-countdown-cnt countdown-'.$rand_id.'">';
				if(trim($brands_attr['show_countdown']) == "yes" )
				{
					if(strtotime($blogtime)<strtotime($pw_to))
					{
						
						$id=rand(0,1000);			
						$ret.='<ul class="fl-'.$brands_attr['countdown_style'].' fl-'.$brands_attr['countdown_size'].' fl-countdown countdown_'.$id.'">
								  <li><span class="days">00</span><p class="days_text">'.$setting['Days'].'</p></li>
									<li class="seperator">:</li>
									<li><span class="hours">00</span><p class="hours_text">'.$setting['Hour'].'</p></li>
									<li class="seperator">:</li>
									<li><span class="minutes">00</span><p class="minutes_text">'.$setting['Minutes'].'</p></li>
									<li class="seperator">:</li>
									<li><span class="seconds">00</span><p class="seconds_text">'.$setting['Seconds'].'</p></li>
								</ul>
							<script type="text/javascript">
								jQuery(".countdown_'.$id.'").countdown({
									date: "'.$rule['pw_to'].'",
									offset: "'.$offset_utc.'",
									day: "Day",
									days: "'.$setting['Days'].'",
									hours: "'.$setting['Hour'].'",
									minutes: "'.$setting['Minutes'].'",
									seconds: "'.$setting['Seconds'].'",
								}, function () {
								//	alert("Done!");
								});
							</script>';
					}
				}	
				if (trim($brands_attr['show_countdown']) == "yes")
					$ret .= '</div>';
		}
	$ret.='</div>';
		
	$ret.='<div class="fl-boxed-detail-unvis">';
		$ret.='<div class="fl-buttons">';
			$ret.='<a class="fl-btn fl-readmore-btn"href="'.PW_Discount_function::show_add_to_cart_product('lable',$p).'" >Add To Cart</a>';
		$ret.='</div>';
	$ret.='</div>';
	$ret.='<div class="fl-thumbnail-img '.$brands_attr['item_image_eff'].'">';
		$ret.=$image;
	$ret.='</div>';
  $ret .='</div><!--fl-thumbnail -->';
$ret .='</div>';
